  
body { font-family: Poppins, sans-serif; background:#eef2fa; }
.container{ max-width:600px; margin:auto; padding:20px; text-align:center; background:#fff;
border-radius:10px; box-shadow:0 0 10px #0002; margin-top:50px; }
button{ background:#0078ff; color:#fff; padding:10px 20px; border:none;
border-radius:5px; margin:10px; cursor:pointer; }
button:hover{ background:#005bcc; }
.quiz-box{text-align:left;}
#options button{ width:100%; margin:5px 0; }
ul li{background:#d0e6ff;padding:10px;margin:5px;border-radius:5px;}